<?php
/**
 * Footersjabloon.
 *
 * @package Diespe
 */

$phone   = get_theme_mod( 'diespe_phone', '+31 653 14 23 95' );
$address = get_theme_mod( 'diespe_address', 'Mercurius 19' );
$postal  = get_theme_mod( 'diespe_postal', '7131 HS Lichtenvoorde' );
$footer_tekst = diespe_home_text( 'footer_tekst', __( 'Partner in duurzame omgevingsprojecten. Project-, Technisch- en Omgevingsmanagement van omgevings- en energieprojecten.', 'diespe' ) );
?>
</main>

<footer class="site-footer" role="contentinfo">
	<div class="diespe-stripes" aria-hidden="true"></div>
	<div class="container">
		<div class="footer-grid footer-grid--twee">
			<div>
				<h4>DIESPE Omgevingsprojecten</h4>
				<p><?php echo esc_html( $footer_tekst ); ?></p>
			</div>
			<div>
				<h4><?php esc_html_e( 'Contact', 'diespe' ); ?></h4>
				<?php if ( $address || $postal ) : ?>
					<p><?php echo esc_html( $address ); ?><br><?php echo esc_html( $postal ); ?><br><?php esc_html_e( 'Nederland', 'diespe' ); ?></p>
				<?php endif; ?>
				<p>
					<?php if ( $phone ) : ?>
						<a href="tel:<?php echo esc_attr( preg_replace( '/\s+/', '', $phone ) ); ?>"><?php echo esc_html( $phone ); ?></a><br>
					<?php endif; ?>
					<a href="mailto:<?php echo esc_attr( antispambot( $email ) ); ?>"><?php echo esc_html( antispambot( $email ) ); ?></a>
				</p>
			</div>
		</div>
		<div class="footer-bottom">
			<span>&copy; <?php echo esc_html( gmdate( 'Y' ) ); ?> DIESPE Omgevingsprojecten</span>
			<span><a href="<?php echo esc_url( wp_get_attachment_url( 2188 ) ); ?>" target="_blank" rel="noopener" style="color:inherit;"><?php esc_html_e( 'Algemene voorwaarden: DNR 2011', 'diespe' ); ?></a> <em style="opacity:.7;">(<?php esc_html_e( 'bron: BNA', 'diespe' ); ?>)</em> &nbsp;&middot;&nbsp; <?php $kvk = get_theme_mod( 'diespe_kvk', '94509832' ); if ( $kvk ) : ?>KvK <?php echo esc_html( $kvk ); ?><?php endif; ?> &nbsp;&middot;&nbsp; <?php esc_html_e( 'Lid van:', 'diespe' ); ?> <a href="https://www.waternetwerk.nl" target="_blank" rel="noopener" style="color:inherit;"><?php esc_html_e( 'KNW — Koninklijk Waternetwerk', 'diespe' ); ?></a></span>
		</div>
	</div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
